@echo off
rem Consolide les exports de caisse du dossier exports_caisse.
cd /d "%~dp0"
py consolider.py 2>nul || python consolider.py
echo.
pause
