"""Consolide les exports de caisse de toutes les boutiques en un seul fichier Excel propre.

Exemple fictif : Comptoir des Épices, 3 boutiques qui exportent chacune leurs ventes
depuis un logiciel de caisse différent (CSV ou Excel, colonnes et formats différents).

Usage : déposer les exports dans le dossier « exports_caisse », puis lancer
    python consolider.py
(ou double-cliquer sur lancer.bat). Le résultat est « ventes_consolidees.xlsx ».

Le script :
- reconnaît chaque format (séparateur, encodage, lignes de titre, noms de colonnes) ;
- convertit les dates et les montants (« 1 234,50 € », « 1234.50 ») ;
- retire les lignes de total et les lignes saisies deux fois ;
- signale tout ce qu'il écarte ou qui mérite une vérification, fichier par fichier :
  rien ne disparaît sans être listé dans l'onglet « Contrôles ».
"""
import csv
import sys
import time
import unicodedata
from pathlib import Path

import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

DOSSIER = Path(__file__).parent
ENTREES = DOSSIER / "exports_caisse"
SORTIE = DOSSIER / "ventes_consolidees.xlsx"

# Boutique reconnue à partir d'un mot du nom de fichier.
BOUTIQUES = {"bordeaux": "Bordeaux", "arc": "Arcachon", "arcachon": "Arcachon", "libourne": "Libourne"}

# Noms de colonnes rencontrés dans les exports -> nom commun.
SYNONYMES = {
    "date": ["date", "date vente", "date_vente", "jour"],
    "ticket": ["ticket", "n ticket", "no ticket", "num_ticket", "numero"],
    "categorie": ["categorie", "famille", "rayon"],
    "quantite": ["quantite", "qte", "qty"],
    "montant": ["montant", "montant ttc", "total_ttc", "total ttc", "ca ttc"],
    "paiement": ["paiement", "mode de paiement", "reglement"],
}
COLONNES = list(SYNONYMES)
MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]


def simplifier(texte) -> str:
    """Minuscules, sans accents ni ponctuation superflue : « N° ticket » -> « n ticket »."""
    t = unicodedata.normalize("NFKD", str(texte)).encode("ascii", "ignore").decode()
    return " ".join(t.lower().replace("°", "").replace(".", " ").split())


INDEX_SYNONYMES = {simplifier(s): nom for nom, liste in SYNONYMES.items() for s in liste}


def boutique_du_fichier(nom: str) -> str:
    mots = simplifier(nom).replace("_", " ").replace("-", " ").split()
    for mot in mots:
        if mot in BOUTIQUES:
            return BOUTIQUES[mot]
    return "Inconnue"


def lire_csv(chemin: Path) -> pd.DataFrame:
    for encodage in ("utf-8-sig", "cp1252"):
        try:
            texte = chemin.read_text(encoding=encodage)
            break
        except UnicodeDecodeError:
            continue
    separateur = csv.Sniffer().sniff(texte.splitlines()[0], delimiters=";,\t").delimiter
    return pd.read_csv(chemin, sep=separateur, encoding=encodage, dtype=str)


def lire_excel(chemin: Path) -> pd.DataFrame:
    brut = pd.read_excel(chemin, header=None, dtype=object)
    # La ligne d'en-tête est la première qui contient une colonne de date reconnue.
    for i in range(min(15, len(brut))):
        if any(INDEX_SYNONYMES.get(simplifier(v)) == "date" for v in brut.iloc[i] if pd.notna(v)):
            table = brut.iloc[i + 1:].copy()
            table.columns = brut.iloc[i]
            return table
    raise ValueError("ligne d'en-tête introuvable")


def montant_en_nombre(valeur):
    if pd.isna(valeur) or str(valeur).strip() == "":
        return None
    if isinstance(valeur, (int, float)):
        return float(valeur)
    t = str(valeur).replace("€", "").replace(" ", "").replace(" ", "").replace(" ", "")
    if "," in t:
        t = t.replace(".", "").replace(",", ".")
    try:
        return float(t)
    except ValueError:
        return None


def date_en_jour(valeur):
    if isinstance(valeur, pd.Timestamp) or hasattr(valeur, "year"):
        return pd.Timestamp(valeur).normalize()
    t = str(valeur).strip()
    if not t or t.upper() == "TOTAL":
        return pd.NaT
    formats = ["%d/%m/%Y", "%Y-%m-%d", "%d-%m-%Y", "%d/%m/%y"]
    for f in formats:
        try:
            return pd.to_datetime(t, format=f)
        except ValueError:
            continue
    return pd.NaT


def traiter(chemin: Path):
    """Retourne (lignes propres, bilan du fichier, anomalies)."""
    boutique = boutique_du_fichier(chemin.stem)
    brut = lire_excel(chemin) if chemin.suffix.lower() in (".xlsx", ".xls") else lire_csv(chemin)
    renommage = {c: INDEX_SYNONYMES[simplifier(c)] for c in brut.columns if simplifier(c) in INDEX_SYNONYMES}
    manquantes = [c for c in COLONNES if c not in renommage.values()]
    if manquantes:
        raise ValueError("colonnes introuvables : " + ", ".join(manquantes))
    df = brut.rename(columns=renommage)[COLONNES].copy()
    lues = len(df)

    df["date"] = df["date"].map(date_en_jour)
    totaux = df["date"].isna()
    df = df[~totaux].copy()

    df["montant"] = df["montant"].map(montant_en_nombre)
    df["quantite"] = pd.to_numeric(df["quantite"], errors="coerce")
    df["categorie"] = df["categorie"].astype(str).str.strip().str.capitalize()
    df["ticket"] = df["ticket"].astype(str).str.strip()
    df["paiement"] = df["paiement"].astype(str).str.strip()
    df.insert(0, "boutique", boutique)

    doublons = df.duplicated(keep="first")
    df = df[~doublons]

    anomalies = []
    sans_montant = df["montant"].isna()
    for _, r in df[sans_montant].iterrows():
        anomalies.append([chemin.name, r["ticket"], r["date"].date(), "Montant manquant : ligne écartée, à vérifier en caisse"])
    df = df[~sans_montant]
    for _, r in df[df["montant"] < 0].iterrows():
        anomalies.append([chemin.name, r["ticket"], r["date"].date(), f"Remboursement de {-r['montant']:.2f} € : conservé"])

    bilan = [chemin.name, boutique, lues, int(totaux.sum()), int(doublons.sum()), int(sans_montant.sum()),
             len(df), round(df["montant"].sum(), 2)]
    return df, bilan, anomalies


def mettre_en_forme(ws, largeurs, formats=None):
    for i, w in enumerate(largeurs, 1):
        ws.column_dimensions[get_column_letter(i)].width = w
    for cell in ws[1]:
        cell.font = Font(bold=True, color="FFFFFF")
        cell.fill = PatternFill("solid", fgColor="1D7A4E")
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    ws.freeze_panes = "A2"
    for col, fmt in (formats or {}).items():
        for cell in ws[col][1:]:
            cell.number_format = fmt


def main():
    debut = time.perf_counter()
    fichiers = sorted(p for p in ENTREES.iterdir() if p.suffix.lower() in (".csv", ".xlsx", ".xls"))
    if not fichiers:
        sys.exit(f"Aucun fichier dans {ENTREES}")
    tables, bilans, anomalies, erreurs = [], [], [], []
    for f in fichiers:
        try:
            df, bilan, anom = traiter(f)
            tables.append(df); bilans.append(bilan); anomalies += anom
            if bilan[1] == "Inconnue":
                anomalies.append([f.name, "", "", "Boutique non reconnue dans le nom du fichier"])
        except Exception as e:  # un fichier illisible ne bloque pas les autres
            erreurs.append([f.name, str(e)])

    ventes = pd.concat(tables, ignore_index=True).sort_values(["date", "boutique", "ticket"])
    ventes["mois"] = ventes["date"].dt.month
    synthese = ventes.pivot_table(index="mois", columns="boutique", values="montant", aggfunc="sum").round(2)
    synthese["Total"] = synthese.sum(axis=1)
    synthese.loc["Total"] = synthese.sum()
    synthese.index = [MOIS[m - 1] if m != "Total" else "Total" for m in synthese.index]
    par_cat = ventes.pivot_table(index="categorie", columns="boutique", values="montant", aggfunc="sum").round(2)
    par_cat["Total"] = par_cat.sum(axis=1)
    par_cat = par_cat.sort_values("Total", ascending=False)

    donnees = ventes.drop(columns="mois").rename(columns={
        "boutique": "Boutique", "date": "Date", "ticket": "N° ticket", "categorie": "Catégorie",
        "quantite": "Quantité", "montant": "Montant TTC (€)", "paiement": "Paiement"})
    bilan_df = pd.DataFrame(bilans, columns=["Fichier", "Boutique", "Lignes lues", "Lignes de total retirées",
                                             "Doublons retirés", "Montants manquants", "Lignes gardées", "Total TTC (€)"])

    with pd.ExcelWriter(SORTIE, engine="openpyxl") as xl:
        synthese.to_excel(xl, sheet_name="Synthèse", index_label="Mois", startrow=0)
        par_cat.to_excel(xl, sheet_name="Synthèse", index_label="Catégorie", startrow=len(synthese) + 3)
        donnees.to_excel(xl, sheet_name="Données", index=False)
        bilan_df.to_excel(xl, sheet_name="Contrôles", index=False)
        pd.DataFrame(anomalies, columns=["Fichier", "N° ticket", "Date", "À savoir"]).to_excel(
            xl, sheet_name="Contrôles", index=False, startrow=len(bilan_df) + 3)
        if erreurs:
            pd.DataFrame(erreurs, columns=["Fichier", "Erreur"]).to_excel(xl, sheet_name="Fichiers illisibles", index=False)

        eur = '#,##0.00 "€";-#,##0.00 "€"'
        s = xl.sheets["Synthèse"]
        mettre_en_forme(s, [14, 14, 14, 14, 16])
        for row in s.iter_rows(min_row=2, min_col=2):
            for c in row:
                c.number_format = eur
        r_cat = len(synthese) + 4
        for c in s[r_cat]:
            c.font = Font(bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="1D7A4E")
        for r in (len(synthese) + 1,):
            for c in s[r]:
                c.font = Font(bold=True)
        d = xl.sheets["Données"]
        mettre_en_forme(d, [12, 12, 14, 14, 10, 16, 14], {"B": "dd/mm/yyyy", "F": eur})
        tab = Table(displayName="Ventes", ref=f"A1:G{len(donnees) + 1}")
        tab.tableStyleInfo = TableStyleInfo(name="TableStyleLight9", showRowStripes=True)
        d.add_table(tab)
        c = xl.sheets["Contrôles"]
        mettre_en_forme(c, [32, 12, 12, 14, 12, 14, 13, 16], {"H": eur})
        r_an = len(bilan_df) + 4
        for cell in c[r_an]:
            cell.font = Font(bold=True, color="FFFFFF"); cell.fill = PatternFill("solid", fgColor="A8741A")
        c.cell(r_an, 4).alignment = Alignment(horizontal="left")

    duree = time.perf_counter() - debut
    print(f"{len(fichiers)} fichiers lus, {len(donnees)} ventes consolidées en {duree:.1f} s")
    print(f"Retirés : {int(bilan_df['Lignes de total retirées'].sum())} lignes de total, "
          f"{int(bilan_df['Doublons retirés'].sum())} doublons, {int(bilan_df['Montants manquants'].sum())} montants manquants")
    print(f"À vérifier : {len(anomalies)} ligne(s), fichiers illisibles : {len(erreurs)}")
    print(f"Résultat : {SORTIE.name}")


if __name__ == "__main__":
    main()
